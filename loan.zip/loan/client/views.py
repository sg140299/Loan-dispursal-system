from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.contrib.auth.hashers import make_password,check_password
from django.core.files.storage import FileSystemStorage
from .models import Users

# Create your views here.
def apply(request):
	return render(request,"application_form.html")

def doapply(request):
	if request.method == "POST":
		if request.session['apply']==False:
			form=Users.objects.get(email = request.session['user'])
			form.name=request.POST['name']
			form.dob=request.POST['dob']
			form.gender=request.POST['gender']
			form.phone=request.POST['phone']
			form.pan=request.POST['pan']
			form.degree=request.POST['degree']
			form.course=request.POST['course']
			form.address=request.POST['address']
			form.pin=request.POST['pin']
			form.borrow=request.POST['borrow']
			form.income=request.POST['income']
			form.loan=request.POST['loan']	
			form.employ=request.POST['employ']	
			form.apply1=True	
			request.session['apply']=form.apply1
			img=request.FILES['images']
			fs=FileSystemStorage()
			fs.save('media/'+img.name,img)
			form.save()
			msg="<h1>Congratulation You Have Successfully Applied for loan</h1>"
			msg+="<h3>You Can Check Your Loan Status at dashboard</h3>"	
		else:
			msg="<h1>User Have Already applied for a loan</h1>"	
		msg+="<h3>To check status</h3>"
		msg+="<a href='/client/dashboard'>Click Here</a>"
		return HttpResponse(msg)

def index(request):
	return render(request,"index.html")

def faq(request):
	return render(request,"faq.html")

def register(request):
	return render(request,"register.html")

def doregister(request):
	if request.method == "POST":
		form = Users()
		try:
			data = Users.objects.get(email = request.POST['email'])
			msg = "User Already Registered Please Login"
		except:
			form.email 		= request.POST['email']
			form.passw  	= make_password(request.POST['pass'])
			form.save()
			msg = "Congratulations you are registered"
			msg +="<a href='/client/login'>Login</a>"
	return HttpResponse("<h1>"+msg+"</h1>")


def login(request):
	data = {}
	if request.session.has_key('user'):
		data['id'] = request.session['user']
		return redirect('/client/dashboard')
	return render(request,"login.html")

def logout(request):
	if request.session.has_key('user'):
		del request.session['user']
	return render(request,"login.html")



def dologin(request):
		data = {}
		if request.method == "POST":
			try:
				user = Users.objects.filter(email = request.POST['email']).values()[0]
				if check_password(request.POST['pass'],user['passw']):
					request.session['user'] = request.POST['email']
					request.session['apply'] = user['apply1']
					request.session.set_expiry(1500)
					data['id'] = request.session['user']
					return redirect('/client/dashboard')
				else:
					msg = "Invalid Password Please Retry "
					msg +="<a href='/client/login'>Relogin</a>"
					return HttpResponse("<h2>"+msg+"</h2>")
			except:
				msg = "User Not Registered Please Register "
				msg += "<a href='/client/register'>Click Here</a>"
				return HttpResponse("<h2>"+msg+"</h2>")
		else:
			return render(request,"login.html") 

def dashboard(request):
	if request.session.has_key('user'):
		request.session.set_expiry(1500)
		data = Users.objects.filter(email = request.session['user']).values()[0]
		return render(request,"dashboard.html",data)
	else:
		return render(request,"login.html")

def condition(request):
	return render(request,"condition.html")