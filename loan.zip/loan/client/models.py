from django.db import models

# Create your models here.
class Users(models.Model):
	name=models.CharField(max_length=60)
	email=models.EmailField(max_length=60, primary_key=True)
	passw=models.CharField(max_length=100,null=True)
	dob=models.CharField(max_length=15)
	gender=models.CharField(max_length=10)
	phone=models.CharField(max_length=15)
	pan=models.CharField(max_length=20)
	degree=models.CharField(max_length=20)
	course=models.CharField(max_length=30)
	address=models.CharField(max_length=60)
	pin=models.CharField(max_length=10)
	borrow=models.CharField(max_length=20)
	employ=models.CharField(max_length=20)
	income=models.CharField(max_length=20)
	loan=models.CharField(max_length=20)
	apply1 = models.BooleanField(default=False) 
	status = models.BooleanField(default=False) 
		
	def __str__(self):
		return self.email 