from django.conf.urls import url
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
	url(r'^apply/', views.apply,name="apply"),
	url(r'^doapply/', views.doapply,name="doapply"),
	url(r'^register/', views.register, name="register"),
    url(r'^login/', views.login, name="login"),
    url(r'^doregister/', views.doregister, name="doregister"),
    url(r'^dologin/', views.dologin, name="dologin"),
    url(r'^dashboard/', views.dashboard,name="dashboard"),
    url(r'^logout/', views.logout,name="logout"),
    url(r'^faq/', views.faq,name="faq"),
    url(r'^condition/', views.condition,name="condition"),
]
if settings.DEBUG:
    urlpatterns +=static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
